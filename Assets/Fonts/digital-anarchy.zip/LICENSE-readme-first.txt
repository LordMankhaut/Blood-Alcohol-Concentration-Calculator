Digital Anarchy is free for PERSONAL use only. If you want to use this for commercial, promotional, or business use, you must purchase a commercial license from:

http://www.chrisvile.com or
http://www.gwizsk.com

visit chrisvile.com for more free fonts